package lib.util;

import java.io.File;
import java.io.FileInputStream;
//import java.io.InputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesFileReaderClass
{
	InputStream stream ;
//	public void propertiesmethod()
//	{
	static Properties prop = new Properties();
	private static PropertiesFileReaderClass INSTANCE = null;
	private static final String prop_file = "common.properties";
//stream = getClass().getClassLoader().getResourceAsStream(propPage);
	static InputStream in = null;
	static
	{
	in = PropertiesFileReaderClass.class.getResourceAsStream("/resources/"+prop_file);
	try {
		prop.load(in);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	public static String getProperty(String key)
	{
		String value = null;
		if(null != key && !"".equalsIgnoreCase(key))
		{
			value = (String) prop.get(key);
		}
		return value;
		
	}

	

}

