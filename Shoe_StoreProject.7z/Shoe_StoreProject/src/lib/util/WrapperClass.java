package lib.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WrapperClass
{
	static WebDriver driver;
	public WrapperClass()
	{
		this.driver = driver;
	}
	public void monthSearch()
	{
		System.out.println("Value is: "+PropertiesFileReaderClass.getProperty("month_1"));
		driver.findElement(By.xpath(".//a[text() = '"+PropertiesFileReaderClass.getProperty("month_1")+"']")).click();
		String monthText = driver.findElement(By.xpath(".//div[@class = 'title']")).getText();
		if(monthText.contains("month_1"))
		{
			System.out.println("User should be able to see january month released products");
		}
		else 
		{
			System.out.println("TestCase Failed");
		}
		//** release products count with brand name
		List<WebElement> countOfMonths = driver.findElements(By.xpath(".//td[@class = 'shoe_result_value shoe_release_month']"));
		System.out.println(countOfMonths.size());
	}
	public void imageCompare()
	{
		List<WebElement> elements = driver.findElements(By.xpath(".//td[@class = 'shoe_image']"));
		System.out.println(elements.size());
		for(int i=1;i<elements.size();i++)
		{
			String value = driver.findElement(By.xpath(("(.//td[@class = 'shoe_image'])["+i+"]"))).getText();
			
			String BrandValues = driver.findElement(By.xpath("(.//td[text() ='Brand'])["+i+"]//following::*[1]")).getText();
			
			String priceofshoe = driver.findElement(By.xpath("(.//td[text()= 'Price'])["+i+"]//following::*[1]")).getText();
			
			System.out.println("Shoe Brand Name" + BrandValues + "Respective shoe price" + priceofshoe);
		}
	}
	
	public void emailIdVerification()
	{	
		driver.findElement(By.xpath(".//input[@id = 'remind_email_input']")).sendKeys(PropertiesFileReaderClass.getProperty("email_id"));
		driver.findElement(By.xpath(".//input[@id = 'remind_email_submit']")).click();
		String successMessage = driver.findElement(By.xpath(".//div[text() = 'Thanks! We will notify you of our new shoes at this email: "+PropertiesFileReaderClass.getProperty("email_id")+"']")).getText();
		System.out.println(successMessage);
		if(successMessage.contains("Thanks! We will notify you of our new shoes at this email:"))
		{
			System.out.println("Able to see success message");
		}
		else
		{
			System.out.println("Success message is not matching");
		}
	}
	
	public void emailIdVerification_Invalid()
	{
		driver.findElement(By.xpath(".//input[@id = 'remind_email_input']")).sendKeys(PropertiesFileReaderClass.getProperty("email_id_invalid"));
		driver.findElement(By.xpath(".//input[@id = 'remind_email_submit']")).click();
		String successMessage = driver.findElement(By.xpath(".//div[text() = 'Invalid email format. Ex. name@example.com']")).getText();
		System.out.println(successMessage);
		if(successMessage.contains("Invalid email format. Ex. name@example.com"))
		{
			System.out.println("Able to see failure message");
		}
		else
		{
			System.out.println("failure message is not matching");
		}
	}
	public void enteringIntoUI()
	{
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://rb-shoe-store.herokuapp.com/");
	}
}
