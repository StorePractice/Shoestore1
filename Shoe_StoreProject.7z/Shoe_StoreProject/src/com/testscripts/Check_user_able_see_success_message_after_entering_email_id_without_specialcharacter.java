package com.testscripts;

import org.testng.annotations.Test;

import lib.util.WrapperClass;

public class Check_user_able_see_success_message_after_entering_email_id_without_specialcharacter 
{
	@Test
	public void execution()
	{
	WrapperClass wc = new WrapperClass();
	wc.enteringIntoUI();
	wc.monthSearch();
	wc.imageCompare();
	wc.emailIdVerification_Invalid();
	}
}
