package com.testscripts;

import org.testng.annotations.Test;

import lib.util.WrapperClass;

public class Check_user_able_to_see_products_january_month_wise_and_able_to_see_BrandName_Price_and_Image_of_the_specific_brand_along_with_email_notification_sucessmessage 
{
	@Test
	public void execution()
	{
	WrapperClass wc = new WrapperClass();
	wc.enteringIntoUI();
	wc.monthSearch();
	wc.imageCompare();
	wc.emailIdVerification();
	}
}
